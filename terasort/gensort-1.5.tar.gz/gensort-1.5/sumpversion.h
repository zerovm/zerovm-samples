static char *sp_version = "1.2.3, svn: 130";
